//
//  TappxAds.h
//  TappxFramework
//
//  Created by Rubén Tappx on 10/2/17.
//  Copyright © 2017 Tappx. All rights reserved.
//


#import <TappxFramework/TappxFramework.h>
#import <TappxFramework/TappxInterstitialViewController.h>
#import <TappxFramework/TappxInterstitialViewControllerDelegate.h>
#import <TappxFramework/TappxBannerViewController.h>
#import <TappxFramework/TappxBannerViewControllerDelegate.h>
#import <TappxFramework/TappxSettings.h>
#import <TappxFramework/TappxErrorAd.h>

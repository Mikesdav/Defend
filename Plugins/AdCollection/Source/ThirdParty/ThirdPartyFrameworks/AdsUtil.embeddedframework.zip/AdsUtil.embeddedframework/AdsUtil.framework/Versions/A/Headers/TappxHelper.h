//
//  TappxHelper.h
//  AdsUtil
//
//  Created by Xufei Wu on 2018/2/12.
//  Copyright © 2018年 Xufei Wu. All rights reserved.
//

#ifndef TappxHelper_h
#define TappxHelper_h


#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>



@interface TappxHelper : NSObject

+ (TappxHelper*) GetDelegate;
- (void) InitSDK:(UIViewController*) viewController AppKey:(NSString*)AppKey;
-(void) ShowBanner:(UIViewController*) viewController isBottom:(BOOL)isBottom;
-(void) HideBanner;
-(void) IsBannerReady:(NSMutableDictionary*)result;
-(void) ShowInterstitialAds:(UIViewController*) viewController;
-(void) IsInterstitalReady:(NSMutableDictionary*)result;

@end

#endif /* TappxHelper_h */

